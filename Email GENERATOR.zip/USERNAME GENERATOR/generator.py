import random
import string  # Import the 'string' module to use ascii_letters for alphabets

# Function to generate a random alphanumeric string of length 'length'
def generate_random_alphanumeric(length):
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

# get user input
num = int(input("Number of words to generate: "))

# read word lists
with open('nouns.txt', 'r') as infile:
    nouns = infile.read().strip().split('\n')
with open('adjectives.txt', 'r') as infile:
    adjectives = infile.read().strip().split('\n')

# read censor list
with open('blacklist.txt', 'r') as inline:
    censored = inline.read().strip().split('\n')

# generate usernames and save to a text file
with open('usernames_output.txt', 'w') as outfile:
    for i in range(num):
        # construct username
        word1 = random.choice(adjectives)
        word2 = random.choice(nouns)

        # check if word2 is censored
        if word2 in censored:
            i -= 1
            continue

        # capitalize first letter
        word1 = word1.title()
        word2 = word2.title()
        
        # generate a random number between 1 and 99
        random_number = random.randint(1, 99)
        
        # create a mix of alphabet and number username
        username = '{}{}{}'.format(word1, word2, generate_random_alphanumeric(2))
        
        # write the username to the file
        outfile.write(username + '\n')

        # success
        print(username)
